# Example: finished story.md (internal tool, qualitative proof only)

This is what a completed `story.md` looks like. The tool is "Distilled", an internal application aimed at MDs and VPs. Notice what it does and does not contain: no figures, no invented outcomes, every claim tagged, and open items where the user still owes an answer.

```markdown
# Story: Distilled

## Proof mode
Qualitative only. [stated] Numbers cannot be shared. Value is shown by what the viewer watches happen on sample data.

## Audience
- Who: MDs and VPs [stated]
- What they value: being able to stand behind a number they are accountable for; knowing a report matches the documented procedure [assumed, confirm]
- What they already know: nothing about the problem yet. An earlier session with this group came away blank; a session with a group who had read the problem statement first went well. [stated]

## Chapter one (where the video starts)
Leaders make decisions from figures that come out of Excel-based reports, and those reports are supposed to follow a written procedure (an SOP). [from project]

## Governing thought
Distilled makes the logic behind a report visible and checks it against its SOP, so you can see what a number rests on and where the report and the procedure disagree. [proposed]

## Why it was built
Not yet provided. Ask: what was the moment or frustration that made someone build this? [assumed, needs user]

## SCQA
- Situation: The numbers leadership relies on come from Excel-based UT reports that are meant to follow an SOP. [stated]
- Complication: The logic lives inside formulas and the SOP lives in a separate document, so nobody can easily see whether they still agree or what a change would touch. [stated]
- Question: How can we be confident in a number when we cannot easily see what it rests on? [proposed]
- Answer: Distilled maps the report's logic, checks it against the SOP, and shows the gaps. [proposed]

## The three proofs (what the video shows)

### Proof 1: See the logic, and what a change touches
- What the viewer sees: a sample report goes in; a workflow map and decision flow appear; one formula is changed and everything it affects lights up. [from project]
- What it means to this audience: the logic behind a number stops being invisible. [proposed]
- Source: to capture, using a synthetic sample report.

### Proof 2: See where the report and the SOP disagree
- What the viewer sees: SOP steps checked against the report, with a missing step flagged at its place in the workflow. [stated]
- What it means to this audience: the gap between what is documented and what is built becomes visible before it matters. [proposed]
- Source: to capture, using a synthetic report with a deliberately missing SOP step.

### Proof 3: See what many reports share
- What the viewer sees: several sample UTs grouped, with the logic they have in common surfaced. [stated]
- What it means to this audience: risk and effort concentrated in shared logic become visible across the portfolio. [proposed]
- Source: to capture, using several synthetic UTs.

## Named, not shown
"...and it writes the equivalent Python for each UT." [stated]

## The line to remember
"See what every number rests on." [proposed]

## Hook options
1. "Change one cell. What else moves?" [proposed]
2. "The SOP says one thing. The spreadsheet does another. Who notices?" [proposed]
3. "Can you explain every number in this report?" [proposed]

## Objections the video should pre-empt
| Question a skeptical senior person asks | One-line answer | Video answers it? |
|---|---|---|
| Does it change our reports or SOPs? | [confirm with user] | yes, if the answer is reassuring |
| Where does our data go? | [confirm with user] | leave for live session |
| How is this different from reviewing the spreadsheet by hand? | [confirm with user] | yes |

## Call to action
"Bring us one UT and its SOP." [proposed]

## Beat map (share of total runtime)
| # | Beat | Share | Purpose | What the viewer should think |
|---|---|---:|---|---|
| 1 | Hook | ~6% | Make the problem felt | "I could not answer that." |
| 2 | Situation + Complication | ~16% | Agree on the problem | "That's how our reports work." |
| 3 | Answer | ~10% | Governing thought | "So it shows me the logic." |
| 4 | Proof 1 | ~20% | Show it | |
| 5 | Proof 2 | ~18% | Show it | |
| 6 | Proof 3 | ~14% | Show it | |
| 7 | Named + remember-line | ~6% | Leave one sentence behind | |
| 8 | Call to action | ~10% | Small next step | |

## Words and claims to avoid
Formula names, cell references, and library names on screen. Any claim about accuracy, savings, or speed, since no figures are available. Any real report content.

## Open items
- Why it was built (the moment): user to supply. [assumed]
- Answers to the three objections above: user to confirm.
- Expand "UT" in plain words on first mention: expansion not assumed; ask the user.
- Confirm what MDs and VPs value most (currently assumed).
- Numbers withheld by user; none used anywhere in this story.
```
