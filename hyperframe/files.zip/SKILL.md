---
name: brag-story
description: Write the story behind a project BEFORE making a video about it. Interviews the user briefly, reads the project, and produces story.md (audience, governing thought, situation/complication/question/answer, at most three proofs, objections, call to action, and a beat map) that /brag reads when planning its video. Use whenever the user wants to "find the story", "figure out the narrative", "explain why we built this", "pitch this to leaders/VPs/MDs/executives", "make people care about this tool", or says they are stuck on storytelling, or before running /brag for an internal tool, a heavy or technical product, or any audience that does not already know the problem. Use it even if the user only says "I don't know what the video should say". Works without any numbers or metrics.
---

# /brag-story

A video plan can only be as good as the story feeding it. `/brag` turns a story into scenes, but it does not decide what the video is *about* or why a busy person should care. This skill makes that decision first and writes it to `story.md`.

It is built for the hard case: a capable, data-heavy tool, shown to senior people who do not yet know the problem. When such a tool is shown as a list of outputs, the audience goes blank. The fix is to give them the problem first and a small number of things to remember, so the video works as a pre-read that makes them want to dig in.

## Workflow

### 1. Gather quietly
- Read the project: README, docs, UI copy, any prior notes. If a live URL or `brag-output/capture/` exists, skim it for what the tool actually shows.
- If `story.md` already exists, treat it as a draft to revise. Move the old one to `story.prev.md` before writing the new one.
- Read [references/exec-principles.md](references/exec-principles.md). It holds the structure rules this skill applies. If the `executive-communication` skill (refoundai/lenny-skills) is installed, read it too as reinforcement; this skill works without it.

### 2. Interview, only for what the project cannot tell you
Ask at most four questions, in one message. Skip any the user already answered in this conversation, and never ask for something visible in the project. Pick from:

1. **Audience.** Who watches this, and what do they care about most (risk, speed, cost, audit, decisions)? What do they already know about the problem?
2. **Why it exists.** What was the moment, frustration, or failure that made someone build it?
3. **What happened when it was shown.** What landed with people who got it, and what went over heads?
4. **The ask.** What should a viewer do right after watching?

Also find out, once, whether the user can share numbers. If they cannot or prefer not to, record `Proof mode: qualitative` and never raise it again. That is a normal and fully supported way to work.

### 3. Build the story
Follow [references/story-template.md](references/story-template.md) section by section. The order matters:

1. **Governing thought.** One plain sentence stating what the tool does for this audience. This is the answer, and it lands early in the video.
2. **SCQA.** Situation (something every viewer agrees with), Complication (what makes it hard), Question (falls out of the first two), Answer (the governing thought, resolving the complication fully).
3. **Chapter one.** Start from the last point the audience already finds obvious, not from the tool's internals.
4. **Proofs.** Choose at most three things to *show*. Everything else is named in one line and not demonstrated. Rank candidates by: visible on screen, surprising, tied to what the audience values, understood without narration.
5. **One memorable line** a viewer could repeat in a meeting.
6. **Objections.** Two or three questions a skeptical senior person would ask, with one-line answers. Mark which the video answers and which stay for the live session. If the user shared real cross-questions from earlier sessions, use those verbatim in spirit.
7. **Call to action.** Small, specific, low-effort.
8. **Beat map.** Map the story to beats with a share of runtime (percentages, so it works for any video length).

### 4. Check, write, hand off
Run the checklist at the end of the template. Write `story.md` in the project root. Then give the user a short summary: the governing thought, the three proofs, the open items, and the next command, for example `/brag --mode promo`, which reads `story.md` when it plans.

## Rules, and why they exist

- **Never invent numbers, percentages, time savings, client names, or dates.** The video goes to senior people; a made-up figure is worse than none. When the user withholds numbers, prove value with things the viewer can *watch happen*: a trace appearing, a gap being flagged, a change rippling through. Do not leave bracketed placeholders for numbers in any beat or on-screen line; note "number withheld" in the open items instead.
- **Tag every claim.** Mark lines `[stated]` (user said it), `[from project]` (read from the project), `[proposed]` (your suggestion), or `[assumed]` (needs confirming). The user should see at a glance what is theirs and what is yours, and `[assumed]` items must appear in Open items.
- **Do not claim capabilities the user did not state or the project does not show.** If unsure whether the tool changes files, sends data anywhere, or integrates with something, ask or mark it `[assumed]`.
- **Answer first, no movie-arc reveal.** Holding the answer back until the end loses senior viewers early. The closing call to action invites a next step; it never withholds the point.
- **Three facts at most.** Senior viewers hold very little from a single viewing. If the story needs more than three things remembered, cut.
- **Outcomes over features.** Say what a leader can now see, trust, or decide, not which functions the tool has. A smart person from another business line should follow every sentence without a glossary. Expand any acronym the user uses on first mention; if you do not know the expansion, ask rather than guess.
- **Sample data only.** The story describes what the tool shows on synthetic or sample data. Never put real report contents, names, internal hostnames, or customer data in `story.md`.
- **Confident phrasing.** In any narration lines you draft, avoid apologetic or hedging words ("just", "sorry", "hopefully").

## Reading a blank room
If the user says an earlier audience "came away blank", treat that as feedback on the message, not the audience. Find what the audience was missing (usually the problem statement, not more detail) and make that the opening of the story.

## Example
[references/example-internal-tool.md](references/example-internal-tool.md) shows a finished `story.md` for an internal analysis tool aimed at senior leaders, written without any numbers. Read it when you want to see the expected level of specificity and tagging.
