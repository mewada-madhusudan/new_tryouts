# Executive-communication principles used by brag-story

Paraphrased from the `executive-communication` skill (refoundai/lenny-skills) and the sources it draws on (Barbara Minto's Pyramid Principle, Casey Winters, Ami Vora, Yuhki Yamashita). Kept here so the skill works even where that skill is not installed.

## 1. Start from the obvious
Begin at the last point in the story that is completely obvious to the audience, then move forward. Starting too deep (formulas, internals) is the most common cause of a blank room. Ask: what does every viewer already believe or live with?

## 2. Speak to what the leader values
Recast the pitch around the audience's own goals (risk, accountability, speed, audit-readiness), not the builder's pride in the tool. The same capability gets described differently for a CTO than for a business head.

## 3. Structure for the decision, not the history
Cut any backstory that does not support the point. The video exists to move someone to a next step, so every beat should earn its place against that step.

## 4. Answer first (Pyramid Principle)
State the conclusion early, then support it. Do not build tension toward a final reveal; senior viewers leave before it. In a short video, the answer should land within roughly the first quarter of the runtime.

## 5. SCQA, with the rules that make it work
- **Situation:** factual and uncontroversial. Anyone on any side should read it and agree it is fair.
- **Complication:** one crisp statement of what changed or what makes things hard.
- **Question:** falls out automatically from the first two. It is usually "what should we do?" or "how can we be sure?". If you struggle to write it, S or C is wrong.
- **Answer:** the governing thought. It must fully resolve the complication, not merely relate to it.

## 6. Three facts at most
Assume a senior viewer will retain about three things from a single pass. Give a minimal set, make a clean opinionated recommendation, and trust the viewer to bring their own context. Showing everything in the hope they pick what matters is how heavy tools lose rooms.

## 7. Make one line repeatable
A good test: could a leader quote your point from memory in a meeting? Distil the core insight to one short, concrete sentence and use it more than once.

## 8. Pre-empt the hard questions
Imagine being the senior person responsible for the outcome. What would you ask before agreeing? Answer the two or three sharpest in the story, so the video earns trust instead of provoking doubt.

## 9. Own the reception
If the audience took away something different from what was intended, the gap is the message's job to close. That is a prompt to simplify, not to explain more.

## 10. Direct language
Remove softeners and apologies from lines a presenter or narrator will say. Plain, confident statements read as competence.
