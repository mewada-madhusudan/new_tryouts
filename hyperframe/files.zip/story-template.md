# story.md template

Write `story.md` in the project root using exactly these sections, in this order. Keep it to about two pages. Tag each substantive line `[stated]`, `[from project]`, `[proposed]`, or `[assumed]`.

```markdown
# Story: [Tool name]

## Proof mode
[numbers available / qualitative only]. If qualitative only: value is shown by what the viewer can watch happen, never by figures.

## Audience
- Who: [roles]
- What they value: [risk / speed / audit / cost / decisions, in their words]
- What they already know: [the problem statement they likely hold, or "nothing yet"]

## Chapter one (where the video starts)
[The last thing this audience finds completely obvious. One or two sentences.]

## Governing thought
[One plain sentence: what this tool does for this audience. Lands within the first quarter of the video.]

## Why it was built
[The moment or frustration behind it, in two or three sentences, told as a person's problem, not a feature list.]

## SCQA
- Situation: [uncontroversial fact]
- Complication: [what makes it hard]
- Question: [falls out of S + C]
- Answer: [the governing thought, resolving the complication]

## The three proofs (what the video shows)
For each, in order:

### Proof 1: [short name]
- What the viewer sees: [observable action on screen, on sample data]
- What it means to this audience: [outcome, not function]
- Source: [capture file, UI area, or "to capture"]

### Proof 2: [short name]
(same fields)

### Proof 3: [short name]
(same fields)

## Named, not shown
[One line listing other capabilities mentioned in passing, e.g. "...and it also does X and Y." Nothing here gets a scene.]

## The line to remember
[One short, concrete sentence a leader could repeat. Use it at least twice in the video.]

## Hook options
1. [A question or image that makes the problem felt in two seconds]
2. [...]
3. [...]

## Objections the video should pre-empt
| Question a skeptical senior person asks | One-line answer | Video answers it? |
|---|---|---|
| [...] | [...] or [confirm with user] | yes / leave for live session |

## Call to action
[One small, specific next step.] [stated] or [proposed]

## Beat map (share of total runtime)
| # | Beat | Share | Purpose | What the viewer should think |
|---|---|---:|---|---|
| 1 | Hook | ~6% | Make the problem felt | "That's us." |
| 2 | Situation + Complication | ~16% | Agree on the problem | "Yes, that's true." |
| 3 | Answer | ~10% | State the governing thought | "So that's what it does." |
| 4 | Proof 1 | ~20% | Show it | |
| 5 | Proof 2 | ~18% | Show it | |
| 6 | Proof 3 | ~14% | Show it | |
| 7 | Named + remember-line | ~6% | Leave one sentence behind | |
| 8 | Call to action | ~10% | Small next step | |

Adjust shares to the story, but the answer must land by about 25% and the proofs must not exceed three.

## Words and claims to avoid
[Jargon this audience will not know, claims the tool cannot support, anything that must not appear on screen.]

## Open items
- [Every `[assumed]` line, with the question needed to confirm it]
- [Anything withheld, e.g. "numbers withheld by user; none used"]
- [Acronyms to expand on first mention]
```

## Self-check before saving

- Can a smart person from another business line follow every sentence with no glossary?
- Is the governing thought one sentence, and does it land by about a quarter of the runtime?
- Are there at most three proofs, each something the viewer can *watch*, not just read?
- Is there any number, percentage, name, or date the user did not give? Remove it.
- Does the story rest on any capability the user or project did not confirm? Tag `[assumed]` and list it in Open items.
- Is there any real data or internal identifier in the file? Replace with sample stand-ins.
- Does the call to action ask for one small thing?
- If proof mode is qualitative, does every proof work without a figure?
