---
name: Digital Concierge
colors:
  surface: '#f9f9ff'
  surface-dim: '#d8d9e3'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3fd'
  surface-container: '#ecedf7'
  surface-container-high: '#e6e7f2'
  surface-container-highest: '#e1e2ec'
  on-surface: '#191b23'
  on-surface-variant: '#424754'
  inverse-surface: '#2e3038'
  inverse-on-surface: '#eff0fa'
  outline: '#727785'
  outline-variant: '#c2c6d6'
  surface-tint: '#005ac2'
  primary: '#0058be'
  on-primary: '#ffffff'
  primary-container: '#2170e4'
  on-primary-container: '#fefcff'
  inverse-primary: '#adc6ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#924700'
  on-tertiary: '#ffffff'
  tertiary-container: '#b75b00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb786'
  on-tertiary-fixed: '#311400'
  on-tertiary-fixed-variant: '#723600'
  background: '#f9f9ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ec'
typography:
  display:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h1:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: '0'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
---

## Brand & Style

This design system is built on the philosophy of **Quiet Efficiency**. As an extension of a professional's workflow, the interface must remain unobtrusive, reducing cognitive load while projecting an image of unwavering reliability. The brand personality is that of a high-level executive assistant: organized, proactive, and precise.

The visual style utilizes a **Corporate Modern** aesthetic with heavy **Minimalist** influences. By prioritizing generous whitespace and a rigid structural grid, the system ensures that complex automation tasks feel manageable. The emotional response is one of "ordered calm"—transitioning the chaotic nature of an inbox into a streamlined, automated experience.

## Colors

The color palette is strictly functional, designed to anchor the user in a professional environment. The **Primary Blue** is reserved for actionable elements and brand signifiers, ensuring it draws attention without causing fatigue. 

The neutral scale is curated to provide a clear hierarchy: 
- **White** is the foundational canvas, used for all primary surfaces to maximize clarity.
- **Light Gray** (#E5E7EB) defines the boundaries of the workspace through subtle, single-pixel borders.
- **Slate and Gray** tones differentiate between structural headings, body copy, and metadata, ensuring that the "Your Personal Assistant" logic is easy to parse at a glance.

## Typography

This design system utilizes **Inter** for all typographic needs, leaning on its utilitarian and highly readable characteristics. The type scale is optimized for information density, common in email and automation interfaces.

Headlines use tighter letter spacing and heavier weights to provide strong visual anchors. Body text is set with generous line heights to maintain legibility during long periods of configuration. Labels and metadata utilize medium and semi-bold weights at smaller sizes to remain legible while occupying minimal screen real estate.

## Layout & Spacing

The layout follows a **Fixed-Fluid hybrid** model. A fixed-width navigation and utility sidebar (280px) provides consistent access to tools, while the main content area expands to fill the viewport, allowing for complex automation "recipe" builders to breathe.

A strict **8px grid system** governs all spatial relationships. Elements are separated by 16px (md) or 24px (lg) increments to create a sense of order. Alignment is the primary tool for organization; all primary content containers must align to the left margin of the fluid grid to maintain a logical reading path for the user.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layering** and **Ambient Shadows**. This design system avoids heavy drop shadows in favor of a "stacked paper" effect.

1.  **Level 0 (Base):** The main background (White).
2.  **Level 1 (Surface):** Cards and main containers, defined by a 1px border (#E5E7EB) and a very soft, diffused shadow (4px blur, 2% opacity) to provide a hint of separation.
3.  **Level 2 (Popovers):** Tooltips and dropdown menus use a slightly more pronounced shadow (12px blur, 6% opacity) to indicate they are temporary layers sitting above the workspace.

Interactivity is communicated through elevation: hovered elements may transition from a flat state to a Level 1 shadow, signaling clickability without changing the physical layout.

## Shapes

The shape language is **Rounded**, utilizing a 0.5rem (8px) base radius for buttons, input fields, and cards. This softens the professional aesthetic, making the tool feel approachable and modern rather than clinical.

- **Pill Shapes:** Reserved exclusively for status toggles, tags, and "Add" buttons to distinguish them from structural elements.
- **Active States:** Active list items or navigation links are characterized by a 4px vertical "accent bar" on the left edge, colored in the Primary Blue, paired with a subtle background tint.

## Components

- **Buttons:** Primary buttons use a solid Primary Blue fill with white text. Secondary buttons use a white background with a Light Gray border.
- **Pill Toggles:** Used for enabling/disabling automation rules. When "On," the background is Primary Blue; when "Off," it is a muted gray.
- **Lists:** Email and task lists feature a 1px bottom border. The active item is marked with the 4px left-border accent and a 5% opacity blue background.
- **Input Fields:** Minimalist design with a 1px #E5E7EB border. On focus, the border transitions to Primary Blue with a soft 2px outer glow.
- **Cards:** Used for grouping automation steps. Cards should have a white background, 8px corner radius, and a subtle border.
- **Automation Flow Nodes:** Distinctive components that represent "If/Then" logic, connected by thin gray lines to visualize the email automation path.
- **Checkboxes & Radios:** Standardized 16px squares/circles with 4px corner radius for checkboxes, using Primary Blue for the selected state.