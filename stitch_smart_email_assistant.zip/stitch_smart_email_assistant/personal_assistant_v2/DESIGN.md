---
name: Personal Assistant v2
colors:
  surface: '#fbf8ff'
  surface-dim: '#dad9e5'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f2ff'
  surface-container: '#eeecf9'
  surface-container-high: '#e8e7f3'
  surface-container-highest: '#e2e1ee'
  on-surface: '#1a1b24'
  on-surface-variant: '#444655'
  inverse-surface: '#2f3039'
  inverse-on-surface: '#f1effc'
  outline: '#757687'
  outline-variant: '#c5c5d8'
  surface-tint: '#2d4ce2'
  primary: '#2a49df'
  on-primary: '#ffffff'
  primary-container: '#4965f9'
  on-primary-container: '#fffbff'
  inverse-primary: '#bac3ff'
  secondary: '#5d5d6e'
  on-secondary: '#ffffff'
  secondary-container: '#e2e0f6'
  on-secondary-container: '#636375'
  tertiary: '#994200'
  on-tertiary: '#ffffff'
  tertiary-container: '#bf5500'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dee0ff'
  primary-fixed-dim: '#bac3ff'
  on-primary-fixed: '#00105b'
  on-primary-fixed-variant: '#002fc9'
  secondary-fixed: '#e2e0f6'
  secondary-fixed-dim: '#c5c5d9'
  on-secondary-fixed: '#191a29'
  on-secondary-fixed-variant: '#454556'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb68f'
  on-tertiary-fixed: '#331200'
  on-tertiary-fixed-variant: '#773200'
  background: '#fbf8ff'
  on-background: '#1a1b24'
  surface-variant: '#e2e1ee'
typography:
  page-title:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  section-label:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  body:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  meta:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  sidebar-width: 260px
  gutter: 24px
---

## Brand & Style

The design system is rooted in a **Corporate/Modern** aesthetic, emphasizing efficiency, trust, and executive-level clarity. It is designed for high-performance SaaS environments where information density must be balanced with visual breathing room. 

The style utilizes a high-contrast structural approach: a deep, immersive sidebar provides a grounded "command center" feel, while the primary content area remains light and airy to promote focus. The interface conveys a sense of "quiet intelligence"—it is utilitarian and unobtrusive, yet feels premium through precise typography and a restrained use of vibrant indigo accents. The emotional response is one of organized control and professional reliability.

## Colors

This design system employs a sophisticated palette built on a foundation of neutral grays and a singular, vibrant Indigo-blue primary. The primary color (#4F6BFF) is reserved for high-intent actions and active states to guide the user's eye without causing fatigue.

The contrast between the **Dark Navy** sidebar and the **Light Gray** background establishes a clear hierarchy of navigation versus workspace. Semantic colors follow industry standards to ensure immediate recognition of system status: Success (Green), Error (Red), and Warning (Amber). Surface colors are strictly white to maintain a clean, "paper-like" quality in the main dashboard area, while borders are kept subtle to define structure without adding visual noise.

## Typography

The typography system relies on **Inter** for its exceptional readability in UI contexts. The hierarchy is tight, avoiding extreme size variances to maintain a professional, data-rich environment. 

**Page Titles** are emphasized through weight rather than massive scale, ensuring they don't dominate the workspace. **Section Labels** use uppercase styling and increased tracking to provide clear structural markers for categorized content. **Monospace** elements should be used for technical data, IDs, or code snippets, providing a distinct visual "texture" for machine-readable information. All body text is optimized for long-form reading and data scanning.

## Layout & Spacing

This design system uses a **Fluid Grid** for the main content area combined with a **Fixed Sidebar**. The layout philosophy is centered on an 8px rhythmic grid to ensure consistent alignment across all components.

The sidebar is fixed at 260px, providing a persistent anchor for navigation. Main content areas utilize 24px (lg) margins and gutters to provide sufficient "white space" that prevents the professional density of the UI from feeling cluttered. Alignment should be strict; all elements must snap to the base spacing units to maintain the system's "engineered" feel.

## Elevation & Depth

Hierarchy in this design system is primarily communicated through **Tonal Layers** and **Low-Contrast Outlines**.

The background layer (#F4F5F7) acts as the floor. Surface elements, such as cards and white-space containers, sit on top with 1px borders (#E5E7EB) rather than heavy shadows. Shadows are used sparingly and are strictly **Ambient**: a soft, 4-8px blur with very low opacity (around 4-6% black) to suggest a subtle lift for interactive elements like hover states or dropdown menus. The sidebar uses depth through color saturation rather than elevation, creating a "receded" appearance that pushes the white surface content forward.

## Shapes

The shape language is categorized as **Rounded**, striking a balance between the rigid efficiency of sharp corners and the playfulness of hyper-rounded designs.

- **Interactive Components:** Buttons, inputs, and selection controls use an 8px radius to feel modern and accessible.
- **Structural Elements:** Cards and larger content modules use a 12px radius, providing a softer container for data.
- **Status Indicators:** Badges, pills, and tags utilize a full-round (999px) radius to distinguish them from interactive buttons and structural cards.

## Components

### Buttons
Buttons are 36px in height. **Primary buttons** use the Indigo-blue fill with white text. **Secondary buttons** utilize a white fill with an E5E7EB border and primary text, creating a clean ghost-button effect. **Danger buttons** use the semantic red fill for destructive actions. All buttons transition to a slightly darker shade on hover.

### Sidebar Items
Navigation items feature a height of 40px with 12px horizontal padding. The inactive state uses muted A0A3B1 text, while the **Active state** uses white text and a vertical indigo-blue indicator bar (4px wide) on the far left or right of the item to signal the current location.

### Input Fields
Inputs are 36px high, matching button scales. They feature a white surface, 1px gray border, and 8px corner radius. On focus, the border transitions to the primary indigo-blue with a 2px soft glow (shadow-tint).

### Cards
Cards are the primary container for dashboard modules. They feature a white surface, 12px radius, and a subtle 1px border. Internal padding for cards should default to 24px (lg) to maintain the clean, professional aesthetic.

### Badges & Pills
Small indicators used for status (e.g., "Active," "Pending"). These are always fully rounded (999px), using a 12px font size with medium weight. For semantic clarity, they use a light tinted background of the semantic color with the dark semantic text on top (e.g., light green background with dark green text).