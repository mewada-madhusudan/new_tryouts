---
name: Skill Catalog HUD
colors:
  surface: '#0d1322'
  surface-dim: '#0d1322'
  surface-bright: '#33394a'
  surface-container-lowest: '#080e1d'
  surface-container-low: '#151b2b'
  surface-container: '#191f2f'
  surface-container-high: '#242a3a'
  surface-container-highest: '#2f3445'
  on-surface: '#dde2f8'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#dde2f8'
  inverse-on-surface: '#2a3040'
  outline: '#87929a'
  outline-variant: '#3e484f'
  surface-tint: '#7bd0ff'
  primary: '#8ed5ff'
  on-primary: '#00354a'
  primary-container: '#38bdf8'
  on-primary-container: '#004965'
  inverse-primary: '#00668a'
  secondary: '#44e2cd'
  on-secondary: '#003731'
  secondary-container: '#03c6b2'
  on-secondary-container: '#004d44'
  tertiary: '#becee4'
  on-tertiary: '#233143'
  tertiary-container: '#a3b2c7'
  on-tertiary-container: '#364557'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c4e7ff'
  primary-fixed-dim: '#7bd0ff'
  on-primary-fixed: '#001e2c'
  on-primary-fixed-variant: '#004c69'
  secondary-fixed: '#62fae3'
  secondary-fixed-dim: '#3cddc7'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005047'
  tertiary-fixed: '#d4e4fa'
  tertiary-fixed-dim: '#b9c8de'
  on-tertiary-fixed: '#0d1c2d'
  on-tertiary-fixed-variant: '#39485a'
  background: '#0d1322'
  on-background: '#dde2f8'
  surface-variant: '#2f3445'
typography:
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  metadata-code:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.05em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: '1'
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  container-max: 1440px
---

## Brand & Style

The design system is engineered for a high-density "Skill Catalog," evoking the atmosphere of a professional command center or technical terminal. The brand personality is precise, analytical, and authoritative, targeting expert users who require rapid data synthesis.

The aesthetic follows a **Corporate HUD (Heads-Up Display)** direction. It prioritizes information density and structural clarity through:
- **Technological Precision:** Utilizing thin 1px lines and geometric corner brackets to frame data.
- **Controlled Luminance:** Employing subtle glows and translucent overlays instead of heavy shadows to establish hierarchy.
- **Functional Sophistication:** Moving away from "gamer" tropes by using a refined palette of deep navies and steel cyans, ensuring the interface feels like a professional tool rather than a toy.

## Colors

The palette is strictly dark-mode, designed to reduce eye strain during prolonged technical review. 

- **Foundation:** The primary background is a deep navy (`#0B1120`), providing a high-contrast base for glowing elements. Surfaces and panels use a lighter charcoal (`#1E293B`) to create structural depth.
- **Accents:** Steel Blue (`#38BDF8`) serves as the primary action and state color. Teal (`#2DD4BF`) is used for success states and secondary highlights.
- **Neutral/Data:** Grays are shifted toward cool blue tones to maintain the HUD atmosphere. 
- **Functional Tone:** Red and warm "alarm" tones are excluded to ensure the environment feels stable and mission-critical.

## Typography

This design system uses a dual-font strategy to distinguish between narrative content and technical data.

- **Primary Interface (Geist/Inter):** Used for all headings and body copy. Geist’s geometric rigor provides a modern, technical feel for titles, while Inter ensures high legibility for descriptions and list items.
- **Technical Metadata (JetBrains Mono):** Reserved for version numbers, IDs, skill categories, and system labels. This monospace typeface reinforces the "catalog" and "terminal" narrative.
- **Scaling:** Headings on mobile scale down by approximately 20%, but the monospace labels remain fixed at 11-12px to maintain their "readout" aesthetic across all devices.

## Layout & Spacing

The layout is built on a strict **4px grid** to ensure mathematical precision in element alignment.

- **Grid Model:** A 12-column fluid grid for desktop, transitioning to a 4-column grid for mobile. 
- **HUD Texture:** Sections are separated by thin 1px lines rather than large gaps. Use "scan-line" textures (horizontal 1px lines with 20% opacity) in the background of primary dashboard areas.
- **Reflow:** On mobile, sidebars collapse into a "Terminal Menu" accessible via a top-right bracketed icon. Data-heavy tables reflow into "Technical Cards" that utilize the corner-bracket framing described in the shapes section.

## Elevation & Depth

Depth is conveyed through **luminance and layering** rather than physical shadows.

- **Tonal Layering:** Background levels are defined by color shift—`#0B1120` (Level 0), `#1E293B` (Level 1), and a semi-transparent `#38BDF8` 5% overlay for active states.
- **Glow Effects:** Instead of drop shadows, use `box-shadow: 0 0 8px rgba(56, 189, 248, 0.3)` for primary buttons and active cards to simulate light emission.
- **Backdrop Blurs:** Modals and overlays use a `20px` backdrop blur with a 70% opacity charcoal tint to maintain visibility of the HUD data beneath.
- **Framing:** Active elements should be framed with 1px "Steel Blue" borders to signify focus.

## Shapes

The design system utilizes a **Sharp (0px)** roundedness philosophy to maintain a rigid, technical appearance.

- **Corner Brackets:** Primary cards and containers must feature L-shaped corner brackets. These are 1px thick, 8px long strokes positioned at the top-left and bottom-right corners, colored in the primary accent.
- **Angled Cuts:** (Optional) Action buttons may feature a 45-degree chamfer on one corner to emphasize the "Angular Panel" aesthetic.
- **Borders:** All container borders are 1px solid. Background grids should use 0.5px lines to remain unobtrusive.

## Components

- **Buttons:** Rectangular with no radius. Primary buttons have a solid `#38BDF8` fill with black text; on hover, they emit a subtle 10px outer glow. Secondary buttons are "Ghost" style with 1px borders.
- **Cards:** Feature a "Terminal Header"—a 24px tall bar at the top containing a Monospace ID or title in a contrasting color. The bottom of the card is framed by the L-bracket shapes.
- **Chips:** Small, monospace-font indicators. They should look like segments of a status bar, using a `#2DD4BF` (Teal) outline for "Mastered" skills and `#94A3B8` for "In Progress."
- **Input Fields:** Use an underline-only or 4-sided 1px border. Labels must be in Monospace, placed above the field with a small `[ ]` or `_` prefix to simulate a command-line prompt.
- **Lists:** Items are separated by a 1px dashed line. Hovering over a list item triggers a "Scan-line" background highlight.
- **Navigation:** A vertical sidebar with "Bracketed Icons." The active link is indicated by a vertical bar and a subtle inner-glow gradient.