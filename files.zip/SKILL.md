---
name: brag
description: Turn the current project website or live app into a short launch sting, a 2-3 minute promo video, or a ~5 minute product demo using Hyperframes. Use when someone says "/brag", "let's brag about this", "make a launch video", "make a promo video", "make a demo video", "turn this into a video", or wants to share what they built. Reads the project code directly, and captures the real running UI via Playwright when a live app exists.
---

# /brag

You built it. Now let's brag about it.

## Invocation dispatch (must happen first)

**Model check.** If you are Claude Opus 5.5 and the invocation doesn't ask for the full workflow (`--full`, "use the full brag") or for voiceover (`--voice`, which brag-slim doesn't do), switch to brag-slim: read `<skill-dir>/slim.md` (the /brag-slim skill, bundled here) and follow it for the rest of this run instead of this file. Pass along the user's input, and pass any other options (`--no-music`, `--title`, …) as plain-language direction. Tell the user in one line first, e.g. "You're on Opus 5.5, so I'm using /brag-slim: I build the whole video myself. Say 'use the full brag' to switch back." If you are any other model, or can't tell which model you are, skip this check.

Before inspecting the project, parse the complete `/brag` invocation. If the
invocation contains `--voice`, set `voice.enabled = true`. Enable narration
only for that run. Do not enable narration automatically and do not fall back
to the normal no-voice workflow.

`/brag` turns the current project website or app into a short, polished,
shareable video using Hyperframes — a quick launch sting, a 2-3 minute
promo, or a ~5 minute demo walkthrough, depending on mode. It is narrow,
opinionated, and fun, and when a live app exists, it captures the real UI
rather than approximating it.

## What this skill does

1. Reads the current project code to understand the app.
2. **If a live app exists (or the mode requires it): captures the real UI via Playwright** — see Step 0.
3. Plans a brag concept specific to this project and writes a single, merged plan + scene-by-scene storyboard (story arc, timing, transitions, audio, capture references — one document, one step).
4. Hands a focused composition brief to Hyperframes, built from real captured assets wherever they exist.
5. Validates, renders, and writes share copy.

## Parsing the invocation

The user may invoke with natural language or flags:

```
/brag
/brag --tone chaotic
/brag --mode promo --tone polished --format vertical
/brag --mode demo
/brag this. Make it feel like a ridiculous startup launch.
```

Parse these options:

| Option | Values | Default |
|---|---|---|
| `--mode` | `short`, `promo`, `demo` | inferred (see step-2-plan.md mode rules); `short` if truly ambiguous |
| `--tone` | preset or freeform description | inferred |
| `--format` | `landscape`, `vertical`, `square` | `landscape` |
| `--duration` | seconds | auto, per mode (short: 15-25s, promo: 120-180s, demo: 280-320s) |
| `--url` | live app URL | auto-detected dev server if running, else none |
| `--no-music` | flag | music on |
| `--no-sfx` | flag | sfx on |
| `--title` | string | inferred from project |
| `--voice` | flag | narration off |

Voice is opt-in. If `--voice` is present, use Kokoro via Hyperframes and do
not add any provider-selection logic. The voice workflow is intentionally
single-provider.

Tone can be a preset (`default`, `polished`, `yc-parody`, `chaotic`, `deadpan`, `cinematic`, `app-store`) or a creative direction such as "fake Series A launch from 2016", "museum exhibit", or "overproduced mobile game ad".

When the user gives freeform tone direction, map it to the nearest preset for pacing and structure, but preserve the user's direction in the plan and composition brief.

## Narration guidance

When `--voice` is enabled, write narration that complements the visuals, does
not simply read visible text, matches scene pacing, sounds natural and
conversational, and moves smoothly between scenes. Keep the script concise and
specific to the product so the voice feels like part of the edit rather than a
separate narration track. In `demo` mode, narration should walk the viewer
through what's happening on screen like a real product tour, not just add mood.

---

## Output directory

By default, output goes to `brag-output/`. To avoid overwriting previous runs, use a timestamped directory:

```
brag-output-2026-05-04-143022/
```

Use a timestamp when:
- The user explicitly asks for a new run without overriding previous results
- A `brag-output/` directory already exists in the project

Generate the timestamp at the start of the run (`YYYY-MM-DD-HHmmss`) and use it consistently for all output paths in that run: capture, plan, brief, composition, render, and share copy.

## Skill directory

`<skill-dir>` is the directory containing this `SKILL.md`. Claude Code prints it as "Base directory for this skill" when the skill loads; for other agents it's wherever the skill was installed. Bundled assets are under `<skill-dir>/assets/` and scripts under `<skill-dir>/scripts/`. Don't guess an install path: a plugin install, a `~/.claude/skills/` copy, and this repo all put it somewhere different.

---

## Step 1: Inspect the project

**Read:** [references/step-1-inspect.md](references/step-1-inspect.md)

Scan the project directory and extract the information needed to plan the brag video.

**Gate:** You can answer all 9 questions in the brag planning rubric.

---

## Step 0: Capture the real UI (when applicable)

**Read:** [references/step-0-capture-ui.md](references/step-0-capture-ui.md)

Run this after Step 1 (so the user flow from Q9 is known) and before Step 2.
Required for `--mode demo`. Strongly recommended for `--mode promo` whenever
a live app is reachable. Optional for `--mode short`.

This step is the fix for low-fidelity recreations: it captures real
screenshots/recordings of the actual running app via Playwright, which
Step 3 then embeds directly as image/video assets instead of rebuilding
the UI from a text description of the code.

**Gate:** `<output-dir>/capture/` has real screenshots covering the Step 1
Q9 user flow, or a stated reason capture wasn't possible (no live app
reachable, and mode doesn't require it).

---

## Step 2: Plan and storyboard (single merged step)

**Read:** [references/step-2-plan.md](references/step-2-plan.md)

Write `<output-dir>/brag-plan.md` (where `<output-dir>` is `brag-output/` or the timestamped variant chosen above). Answer the planning rubric, decide the mode, commit to a creative angle, and write the full Scene Timeline — story arc, per-scene timing, transitions, audio, and capture references — as one document. Do not run story-arc planning and storyboarding as separate passes; this step owns both.

When music is selected, include a compact `Music cue guidance` section: read the bundled track's cue preset from `<skill-dir>/assets/music/cues/` if present, otherwise note cues will be detected at composition time (any track now supports beat sync — see `references/audio.md`). Cue metadata is optional timing guidance only: story, readability, pacing, and product clarity stay primary.

**Gate:** `<output-dir>/brag-plan.md` exists with a declared mode and a full Scene Timeline. Scene durations sum within that mode's target range (short: 15-25s, promo: 120-180s, demo: 280-320s).

---

## Step 3: Hand off to Hyperframes

**Read:** The Hyperframes domain skills — `hyperframes-core`, `hyperframes-animation`, `hyperframes-creative`, `hyperframes-keyframes`, `hyperframes-cli`. /brag is its own workflow: do not enter the `hyperframes` entry-point intent interview or route into its generic promo / launch-video workflow.
**Read:** [references/step-3-compose.md](references/step-3-compose.md)
**Read:** [references/audio.md](references/audio.md)

Write the composition brief and use Hyperframes to create the video implementation in `<output-dir>/composition/`. Wherever `brag-plan.md` references a Step 0 capture file, embed that real asset in the composition — do not redraw it as new HTML approximating what the screenshot shows (see step-0-capture-ui.md, "How Step 3 must use these captures").

`/brag` owns the product angle, source material, storyboard, tone, format, audio selection, music cue guidance, and delivery expectations. Hyperframes owns the concrete composition structure, exact animation timing, animation mechanics, runtime choices, linting rules, and render workflow.

**Gate:** `npx hyperframes check` passes with zero errors inside `<output-dir>/composition/` (the single browser gate before render — see hyperframes-cli for what it audits).

---

## Step 4: Validate, render, and deliver

**Read:** [references/step-4-deliver.md](references/step-4-deliver.md)

Validate, preview, render to `<output-dir>/brag.mp4`, pick the best poster frame into `<output-dir>/brag.jpg`, bake that poster as the video's frame 0 so it's the idle thumbnail everywhere, and write `<output-dir>/share-copy.txt`.

**Gate:** `<output-dir>/brag.mp4` exists. A best-frame poster `<output-dir>/brag.jpg` is picked (not an arbitrary frame) and baked as frame 0 of `brag.mp4`. Share copy is written.

---

## Tone system

Seven tone presets ship with `/brag`. Each changes scripting energy, pacing, typography personality, and transition style. Presets are defaults, not limits. Tone applies across all three modes; mode sets scene count and total duration, tone sets energy within that.

Full definitions: [references/tones.md](references/tones.md)

| Tone | Energy | One-liner |
|---|---|---|
| `default` | Playful, clean, postable | The good-vibes default |
| `polished` | Serious, elegant | For projects that are not jokes |
| `yc-parody` | Deadpan startup energy | Fake seriousness applied to absurd projects |
| `chaotic` | Fast, loud, aggressive | Over-the-top and unhinged |
| `deadpan` | Calm, dry, understated | The joke is that nothing is a joke |
| `cinematic` | Dramatic, trailer-scale | Big motion, bigger claims |
| `app-store` | Smooth, feature-card clean | Corporate but not boring |

Always allow a freeform creative direction to refine or override the preset.

---

## Creative laws

These apply to every brag video regardless of tone.

**Right length for the mode.** `short` mode: 15-25 seconds, not one second more without a reason. `promo` mode: 2-3 minutes. `demo` mode: ~5 minutes. This holds whether or not narration is on; narration does not extend the window beyond the mode's target.

**Readable.** Keep the pace high through motion and cuts, never by flashing text. Every line a viewer must read holds long enough to read it (short label ~0.8s settled; a sentence ~0.3s per word). Fast-in, then hold — never fast-in, then gone.

**Specific.** The video must feel like it was made for this exact project, not any project.

**Show the real thing.** At least one scene must display actual UI, copy, or a key visual from the product. When a live app exists, prefer a real captured screenshot (Step 0) over a hand-rebuilt approximation — fidelity to the actual product beats a stylized guess at what it looks like. No abstract filler.

**No generic SaaS language.** "Streamline your workflow" is banned. Use the project's actual copy and claims.

**The hook is everything.** The first 2-3 seconds determine whether someone keeps watching, in every mode — a 5-minute demo that opens slowly loses viewers just as fast as a 20-second sting would.

**Funny earns its place.** Humor should come from the project's absurdity, not from trying to be funny. (Primarily relevant to `short`/`promo` mode; `demo` mode is generally played straighter.)

**Pattern (`short` mode):**
```
Hook (2-3s) → Reveal (2-4s) → 2-3 sharp highlights (5-12s) → Punchline/outro (2-4s)
```

**Pattern (`promo` mode):**
```
Hook (2-3s) → Problem/context → Product reveal → 3-5 proof points/flow beats → Social proof (if available) → CTA
```

**Pattern (`demo` mode):**
```
Hook (2-3s) → What this is (10-15s) → Full real-flow walkthrough, beat by beat → Recap of value → CTA
```

Adapt these. Not every project needs exactly 3 highlights, and not every demo needs every flow beat — the pattern is a starting shape, not a template.
