# How to apply this patch to your installed /brag skill

This patches 1 file and adds 1 new file inside your existing brag skill
install. It does NOT touch step-1-inspect.md, step-3-compose.md,
step-4-deliver.md, audio.md, tones.md, assets/, or scripts/ — those are
unchanged and still required.

## 1. Find your installed skill folder
Likely one of:
- `~/.claude/skills/brag/`
- `.claude/skills/brag/` (project-local)
- wherever `npx skills add` placed it — check with the agent: ask it
  "what is <skill-dir> for the brag skill?"

## 2. Back up the two files you're replacing
```bash
cp <skill-dir>/SKILL.md <skill-dir>/SKILL.md.bak
```
(step-2-plan.md is new content replacing old content; step-0 is brand new)

## 3. Copy the patched files in
```bash
cp SKILL.md <skill-dir>/SKILL.md
cp references/step-2-plan.md <skill-dir>/references/step-2-plan.md
cp references/step-0-capture-ui.md <skill-dir>/references/step-0-capture-ui.md
```

## 4. What changed, in one line each
- SKILL.md: added `--mode short|promo|demo`, a new Step 0 gate, merged
  Step 2 (plan+storyboard are now one pass, not two skills), updated
  Creative laws to be mode-aware instead of hard-coded 15-25s.
- step-0-capture-ui.md (new): scripts real Playwright screenshot/recording
  capture of your actual running app, and requires Step 3 to embed those
  real assets instead of redrawing approximations — this is the fix for
  the "10% similar UI" problem.
- step-2-plan.md: merged video-plan's story-arc/scene-timeline structure
  and brag's existing storyboard fields into one Scene Timeline table,
  with per-mode duration and scene-count rules (short/promo/demo).

## 5. Try it
```
/brag --mode demo --url http://localhost:3000
```
or
```
/brag --mode promo
```
Mode defaults to `short` (original behavior) if you don't pass `--mode`,
so existing short-video usage is unaffected unless you opt in.

## 6. If Step 0 capture still doesn't look right
Check that your agent actually has Playwright available in this project
(`npx playwright --version`) and that the URL in `--url` (or an
auto-detected dev server) is actually reachable before the agent starts
Step 2 — Step 0's gate should refuse to proceed silently without captures
when mode is `demo`.
