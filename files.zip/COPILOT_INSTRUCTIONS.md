# Copilot Instructions — How to Use These Files

## The Problem This Solves
Instead of describing the Stitch design in words and hoping Copilot recreates it,
these files ARE the Stitch design already converted to React TSX.
Use them as the source of truth — do not restyle or redesign anything.

---

## File List

| File | Purpose |
|------|---------|
| `tailwind.config.ts` | Exact design tokens from Stitch. Replace your existing tailwind.config.ts with this. |
| `Sidebar.tsx` | Sidebar nav component. Drop into `src/components/Layout/Sidebar.tsx` |
| `Header.tsx` | Top header bar. Drop into `src/components/Layout/Header.tsx` |
| `ScheduledTask.tsx` | Scheduled Task page. Drop into `src/pages/ScheduledTask.tsx` |
| `Logs.tsx` | Logs page with drawer. Drop into `src/pages/Logs.tsx` |

---

## How to Use With Copilot

### Step 1 — Replace tailwind config
Replace your `tailwind.config.ts` entirely with the provided file.
All Stitch design tokens (colors, spacing, font sizes) are defined here.
Do NOT add Inter or JetBrains Mono to fontFamily — they load via CDN in index.html.

### Step 2 — Add CDN links to index.html
```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
```
And in your global CSS:
```css
.material-symbols-outlined {
  font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
}
```

### Step 3 — Drop in components
Copy each .tsx file to the path shown in the table above.
The Sidebar and Header are already wired to React Router NavLink.

### Step 4 — Build remaining pages using these as reference
For pages not yet converted (Mailbox, NewTask, ImportExport), give Copilot this prompt:

```
Build [PageName].tsx following the exact same patterns as the provided ScheduledTask.tsx and Logs.tsx files.
- Use the same Tailwind token names (bg-primary, text-on-surface-variant, rounded-xl, etc.)
- Use the same Material Symbols Outlined icon pattern: <span className="material-symbols-outlined">icon_name</span>
- Use the same card pattern: bg-surface-container-lowest rounded-xl border border-outline-variant shadow-sm
- Use the same button patterns from ScheduledTask.tsx
- Import Header from '../components/Layout/Header'
- Do NOT use any hardcoded hex colors — only the token names from tailwind.config.ts
```

---

## Key Token Reference (most used)

### Colors
- Page background: `bg-surface`
- Cards: `bg-surface-container-lowest border border-outline-variant`
- Primary button: `bg-primary text-on-primary hover:bg-primary-container`
- Secondary button: `bg-surface-container-lowest border border-outline-variant text-primary`
- Disabled button: `bg-surface-variant text-on-surface-variant cursor-not-allowed`
- Error row: `bg-error-container/20 border-l-4 border-l-error`
- Active nav: `text-white border-l-4 border-[#4F6BFF] bg-[#4F6BFF]/10`

### Typography
- Page title: `font-page-title text-page-title text-on-surface`
- Body text: `font-body text-body text-on-surface`
- Muted text: `font-meta text-meta text-on-surface-variant`
- Section label: `font-section-label text-section-label text-on-surface-variant uppercase tracking-wider`
- Monospace: `font-mono text-mono`

### Layout
- Sidebar offset: `md:ml-sidebar-width`
- Page padding: `p-lg` (= 24px)
- Card gap: `gap-lg`
- Sidebar width: `w-sidebar-width` (= 260px)

### Toggle (enabled/disabled)
```tsx
<div
  onClick={handleToggle}
  className={`w-10 h-6 rounded-full relative cursor-pointer shadow-inner transition-colors ${
    enabled ? 'bg-primary' : 'bg-surface-variant border border-outline-variant/50'
  }`}
>
  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${
    enabled ? 'right-1' : 'left-1'
  }`} />
</div>
```

### Filter pill tabs (pill style — used in Logs)
```tsx
<button className={activeFilter === f
  ? 'bg-primary text-on-primary font-meta text-meta font-medium px-4 py-1.5 rounded-full'
  : 'bg-surface-container text-on-surface-variant font-meta text-meta font-medium px-4 py-1.5 rounded-full border border-outline-variant/50'
}>
```

### Filter underline tabs (underline style — used in ScheduledTask)
```tsx
<button className={activeFilter === f
  ? 'py-4 text-sm font-medium text-primary border-b-2 border-primary'
  : 'py-4 text-sm font-medium text-on-surface-variant hover:text-on-surface border-b-2 border-transparent'
}>
```
