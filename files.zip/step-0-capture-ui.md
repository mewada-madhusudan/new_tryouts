# Step 0: Capture the real UI (when a live app exists)

This step exists because recreating UI from source code reading alone
produces low-fidelity approximations — colors and copy are usually right,
but layout, spacing, real content density, and actual component rendering
are not. If the product is a running web or desktop app (not just a static
marketing site), capture it directly instead of rebuilding it from memory
of the code.

**Gate to enter this step:** a live URL is reachable (dev server, staging,
prod) OR the user passed `--url <address>`, OR mode is `demo` (demo mode
always requires real captured screens — see Step 2 mode rules).

If no live app is reachable and mode is not `demo`, skip this step and fall
back to Step 1's code-reading approach, but say so explicitly in
`brag-plan.md`: "No live app reachable — UI recreated from source, fidelity
may be approximate."

## What this step produces

A folder of real, captured visual material that Step 3 composition embeds
directly — as images/video, not as hand-rebuilt HTML approximations:

```
<output-dir>/capture/
  screenshots/
    01-landing.png
    02-dashboard.png
    03-key-action.png
    04-result.png
  recordings/
    flow-entry-to-result.webm   (optional, only if a flow is worth showing in motion)
  capture-notes.md
```

## How to capture

Use Playwright (already a Hyperframes dependency, so no new install
required). Script it directly — don't ask the user to do this manually.

```js
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  await page.goto(URL, { waitUntil: 'networkidle' });
  await page.screenshot({ path: 'capture/screenshots/01-landing.png', fullPage: false });

  // Navigate the real user flow identified in Step 1 Q9 (entry -> key action -> result).
  // Click/type/scroll exactly as a real user would — do not skip states.
  // Capture one screenshot per meaningful state, not just start/end.

  await browser.close();
})();
```

Rules:

- **Capture viewport frames, not full-page scrolls**, unless a scroll
  reveal is specifically part of the plan. A full-page screenshot
  stretched into a 1080x1920 composition looks nothing like how a real
  user sees the app.
- **Capture the actual states a user flow passes through** — not just the
  landing page. If Step 1 Q9 identified entry -> key action -> result,
  capture at minimum one screenshot per beat. This is the single biggest
  fidelity win: a composition built around 3-4 real captured states reads
  as "the real app" in a way no rebuilt approximation does.
- **If the app requires auth to reach the real screens**, use a test/demo
  account if one exists. Never capture or carry forward real customer
  data, emails, names, or tokens — same secrecy rule as Step 1. If a
  captured screenshot contains real user data, redact it (blur/box-out)
  before it leaves this step, or substitute a seeded demo account.
- **Capture at 2x device scale factor** (`deviceScaleFactor: 2` in the
  Playwright context) so stills hold up when Hyperframes scales or crops
  them into the final frame.
- **For desktop apps** (not web), the equivalent is a real OS-level
  screenshot/recording of the running app window — Playwright does not
  apply; use the platform's native screenshot capability and apply the
  same rules (real states, redact real data, capture the actual flow).

## How Step 3 must use these captures

This is the part that fixes the fidelity complaint. Composition must:

- **Embed captured screenshots as actual image assets** in the
  composition (`<img>` / background-image referencing the real PNG/WEBM
  files), cropped/framed/animated (Ken Burns, device-frame mockup, parallax
  reveal) — not redrawn as new HTML elements that approximate what the
  screenshot shows.
- Use a **device frame or browser chrome mockup** around captured
  screenshots when it suits the tone (e.g. a laptop/phone bezel) so the
  real screenshot reads clearly as "the actual product," not a floating
  image.
- Only fall back to hand-built HTML recreation for moments that have no
  corresponding capture (e.g. a stat callout, a logo reveal, text-forward
  beats) — never for the core "show the real UI" moments once a capture
  exists for them.
- If a captured screenshot is poor material for video (too much visual
  noise, wrong aspect ratio, low contrast against other scenes), it is
  still the fidelity source: crop into it, zoom on the relevant region, or
  frame it smaller within a scene — do not discard it in favor of a
  rebuilt approximation.

## Gate

`<output-dir>/capture/` exists with at least one real screenshot per flow
beat identified in Step 1 Q9 (or a stated reason none was reachable), and
`brag-plan.md`'s "Visual identity" / storyboard sections reference specific
capture files by name (e.g. "Scene 2 uses `capture/screenshots/02-dashboard.png`"),
not generic descriptions of what the UI looks like.
