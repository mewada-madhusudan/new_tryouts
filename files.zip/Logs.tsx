import { useState } from 'react'
import Header from '../components/Layout/Header'

type StatusFilter = 'All' | 'Success' | 'Failed' | 'Skipped'
type LogStatus = 'Success' | 'Failed' | 'Skipped'

interface LogEntry {
  id: string
  taskName: string
  timestamp: string
  duration: string
  status: LogStatus
}

// Placeholder — replace with API fetch from GET /api/logs
const MOCK_LOGS: LogEntry[] = [
  { id: '1',  taskName: 'Invoice Flagging Rule',        timestamp: '2023-10-27 14:32:01', duration: '1.2s',   status: 'Success' },
  { id: '2',  taskName: 'Daily Sync: CRM to Mailchimp', timestamp: '2023-10-27 14:30:00', duration: '45.0s',  status: 'Failed'  },
  { id: '3',  taskName: 'Lead Triage Automation',       timestamp: '2023-10-27 14:15:22', duration: '0.8s',   status: 'Success' },
  { id: '4',  taskName: 'Weekly Report Generator',      timestamp: '2023-10-27 13:00:05', duration: '3.4s',   status: 'Success' },
  { id: '5',  taskName: 'Database Backup: EU-West',     timestamp: '2023-10-27 12:00:00', duration: '120.5s', status: 'Failed'  },
  { id: '6',  taskName: 'Invoice Flagging Rule',        timestamp: '2023-10-27 11:32:01', duration: '1.1s',   status: 'Success' },
  { id: '7',  taskName: 'New User Onboarding Drip',     timestamp: '2023-10-27 10:45:12', duration: '0.4s',   status: 'Success' },
  { id: '8',  taskName: 'Lead Triage Automation',       timestamp: '2023-10-27 09:15:22', duration: '0.9s',   status: 'Success' },
  { id: '9',  taskName: 'Daily Sync: CRM to Mailchimp', timestamp: '2023-10-26 14:30:00', duration: '42.1s',  status: 'Success' },
  { id: '10', taskName: 'Invoice Flagging Rule',        timestamp: '2023-10-26 14:32:01', duration: '1.0s',   status: 'Success' },
]

const STATUS_FILTERS: StatusFilter[] = ['All', 'Success', 'Failed', 'Skipped']

function StatusBadge({ status }: { status: LogStatus }) {
  const styles: Record<LogStatus, string> = {
    Success: 'bg-primary-container/10 text-primary',
    Failed:  'bg-error/10 text-error',
    Skipped: 'bg-surface-container text-on-surface-variant',
  }
  const dotStyles: Record<LogStatus, string> = {
    Success: 'bg-primary',
    Failed:  'bg-error',
    Skipped: 'bg-outline',
  }
  return (
    <span className={`inline-flex items-center gap-1 font-meta text-meta px-2.5 py-0.5 rounded-full font-medium ${styles[status]}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dotStyles[status]}`} />
      {status}
    </span>
  )
}

export default function Logs() {
  const [activeFilter, setActiveFilter] = useState<StatusFilter>('All')
  const [search, setSearch] = useState('')
  const [drawerLog, setDrawerLog] = useState<LogEntry | null>(null)

  // Summary counts — replace with GET /api/logs/summary
  const total = MOCK_LOGS.length
  const successful = MOCK_LOGS.filter((l) => l.status === 'Success').length
  const failed = MOCK_LOGS.filter((l) => l.status === 'Failed').length

  const filtered = MOCK_LOGS.filter((l) => {
    const matchStatus = activeFilter === 'All' || l.status === activeFilter
    const matchSearch = l.taskName.toLowerCase().includes(search.toLowerCase())
    return matchStatus && matchSearch
  })

  return (
    <div className="flex-1 flex flex-col md:ml-sidebar-width h-full">
      <Header title="Logs" />

      <main className="flex-1 p-lg flex flex-col gap-lg overflow-y-auto bg-surface">

        {/* Page header */}
        <div>
          <h2 className="font-page-title text-page-title text-on-surface">Execution Logs</h2>
          <p className="font-body text-body text-on-surface-variant mt-1">Review the outcomes of your automated tasks.</p>
        </div>

        {/* Stat strip */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-lg">
          {/* Total */}
          <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-lg flex items-center justify-between shadow-sm shadow-black/5">
            <div>
              <p className="font-section-label text-section-label text-on-surface-variant uppercase tracking-wider mb-2">Total Runs</p>
              <p className="font-page-title text-[32px] leading-tight font-bold text-on-surface">{total}</p>
            </div>
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1", fontSize: '24px' }}>monitoring</span>
            </div>
          </div>
          {/* Successful */}
          <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-lg flex items-center justify-between shadow-sm shadow-black/5">
            <div>
              <p className="font-section-label text-section-label text-on-surface-variant uppercase tracking-wider mb-2">Successful</p>
              <p className="font-page-title text-[32px] leading-tight font-bold text-on-surface">{successful}</p>
            </div>
            <div className="w-12 h-12 rounded-full bg-primary-container/20 flex items-center justify-center text-primary-container">
              <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1", fontSize: '24px' }}>check_circle</span>
            </div>
          </div>
          {/* Failed */}
          <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-lg flex items-center justify-between shadow-sm shadow-black/5">
            <div>
              <p className="font-section-label text-section-label text-on-surface-variant uppercase tracking-wider mb-2">Failed</p>
              <p className="font-page-title text-[32px] leading-tight font-bold text-error">{failed}</p>
            </div>
            <div className="w-12 h-12 rounded-full bg-error/10 flex items-center justify-center text-error">
              <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1", fontSize: '24px' }}>error</span>
            </div>
          </div>
        </div>

        {/* Filter row */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-md bg-surface-container-lowest p-md rounded-xl border border-outline-variant">
          <div className="flex items-center gap-2">
            {STATUS_FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={`font-meta text-meta font-medium px-4 py-1.5 rounded-full transition-colors ${
                  activeFilter === f
                    ? 'bg-primary text-on-primary'
                    : 'bg-surface-container hover:bg-surface-container-high text-on-surface-variant border border-outline-variant/50'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-md">
            <div className="relative">
              <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline text-[18px]">search</span>
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search logs..."
                className="h-[36px] pl-9 pr-4 w-64 bg-surface-container-lowest border border-outline-variant rounded-lg text-body font-body text-on-surface placeholder:text-outline focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
              />
            </div>
            <button className="h-[36px] px-4 bg-surface-container-lowest border border-outline-variant text-primary font-body text-body font-medium rounded-lg hover:bg-surface-container transition-colors flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px]">download</span>
              Export Logs
            </button>
          </div>
        </div>

        {/* Log table */}
        <div className="bg-surface-container-lowest rounded-xl border border-outline-variant overflow-hidden shadow-sm shadow-black/5 flex-1 flex flex-col">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-surface-container-low border-b border-outline-variant">
                  <th className="py-3 px-6 font-section-label text-section-label text-on-surface-variant w-2/5">Task Name</th>
                  <th className="py-3 px-6 font-section-label text-section-label text-on-surface-variant w-1/5">Timestamp</th>
                  <th className="py-3 px-6 font-section-label text-section-label text-on-surface-variant w-1/5">Duration</th>
                  <th className="py-3 px-6 font-section-label text-section-label text-on-surface-variant w-1/5">Status</th>
                  <th className="py-3 px-6 font-section-label text-section-label text-on-surface-variant text-right">Action</th>
                </tr>
              </thead>
              <tbody className="font-body text-body text-on-surface divide-y divide-outline-variant">
                {filtered.map((log) => (
                  <tr
                    key={log.id}
                    className={`transition-colors ${
                      log.status === 'Failed'
                        ? 'bg-error-container/20 border-l-4 border-l-error hover:bg-error-container/30'
                        : 'hover:bg-surface-container border-l-4 border-l-transparent'
                    }`}
                  >
                    <td className="py-3 px-6 font-medium pl-5">{log.taskName}</td>
                    <td className="py-3 px-6 font-mono text-mono text-on-surface-variant">{log.timestamp}</td>
                    <td className="py-3 px-6 font-mono text-mono text-on-surface-variant">{log.duration}</td>
                    <td className="py-3 px-6"><StatusBadge status={log.status} /></td>
                    <td className="py-3 px-6 text-right">
                      <button
                        onClick={() => setDrawerLog(log)}
                        className="text-primary hover:text-primary-container font-medium text-[13px] hover:underline"
                      >
                        View Log
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="bg-surface-container-lowest border-t border-outline-variant px-6 py-4 flex items-center justify-between mt-auto">
            <p className="font-meta text-meta text-on-surface-variant">Showing 1 to {filtered.length} of 142 entries</p>
            <div className="flex items-center gap-2">
              <button disabled className="w-8 h-8 flex items-center justify-center rounded border border-outline-variant text-outline hover:bg-surface-container hover:text-on-surface transition-colors disabled:opacity-50">
                <span className="material-symbols-outlined text-[18px]">chevron_left</span>
              </button>
              {[1, 2, 3].map((p) => (
                <button
                  key={p}
                  className={`w-8 h-8 flex items-center justify-center rounded font-meta text-meta font-medium ${
                    p === 1
                      ? 'bg-primary text-on-primary'
                      : 'border border-outline-variant text-on-surface-variant hover:bg-surface-container transition-colors'
                  }`}
                >
                  {p}
                </button>
              ))}
              <span className="text-outline mx-1">...</span>
              <button className="w-8 h-8 flex items-center justify-center rounded border border-outline-variant text-on-surface-variant hover:bg-surface-container transition-colors font-meta text-meta font-medium">15</button>
              <button className="w-8 h-8 flex items-center justify-center rounded border border-outline-variant text-on-surface-variant hover:bg-surface-container transition-colors">
                <span className="material-symbols-outlined text-[18px]">chevron_right</span>
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Log drawer */}
      {drawerLog && (
        <>
          <div className="fixed inset-0 bg-black/30 z-40" onClick={() => setDrawerLog(null)} />
          <div className="fixed inset-y-0 right-0 w-[480px] bg-inverse-surface z-50 flex flex-col shadow-xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
              <div>
                <h3 className="text-inverse-on-surface font-semibold text-base">{drawerLog.taskName}</h3>
                <p className="text-inverse-on-surface/60 font-mono text-mono mt-0.5">{drawerLog.timestamp}</p>
              </div>
              <button onClick={() => setDrawerLog(null)} className="text-inverse-on-surface/60 hover:text-inverse-on-surface transition-colors">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-lg">
              {/* Placeholder log lines — replace with GET /api/logs/:id */}
              <pre className="font-mono text-mono space-y-1">
                <div className="text-inverse-on-surface/70">[INFO]  Starting task: {drawerLog.taskName}</div>
                <div className="text-inverse-on-surface/70">[INFO]  Connecting to mailbox...</div>
                <div className="text-inverse-on-surface/70">[INFO]  Connection established</div>
                {drawerLog.status === 'Failed' ? (
                  <div className="text-error-container">[ERROR] Task failed: Connection timeout after 45s</div>
                ) : (
                  <div className="text-primary-fixed">[SUCCESS] Task completed in {drawerLog.duration}</div>
                )}
              </pre>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
