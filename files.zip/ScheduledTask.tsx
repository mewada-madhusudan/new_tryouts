import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Header from '../components/Layout/Header'

type FilterType = 'All' | 'Enabled' | 'Disabled'

interface Task {
  id: string
  name: string
  icon: string
  iconColorClass: string
  lastRun: string
  schedule: string
  enabled: boolean
}

// Placeholder data — replace with useTaskStore() + API fetch
const MOCK_TASKS: Task[] = [
  { id: '1', name: 'Sync CRM Data',          icon: 'sync',         iconColorClass: 'bg-primary/10 text-primary',                    lastRun: '4 minutes ago',  schedule: 'Every 15 min',   enabled: true  },
  { id: '2', name: 'Daily Digest Summary',   icon: 'summarize',    iconColorClass: 'bg-tertiary-container/10 text-tertiary',         lastRun: '2 hours ago',    schedule: 'Daily at 8:00 AM', enabled: true },
  { id: '3', name: 'Weekly Database Backup', icon: 'database',     iconColorClass: 'bg-surface-variant text-on-surface-variant',    lastRun: '5 days ago',     schedule: 'Weekly on Sun',  enabled: false },
  { id: '4', name: 'Purge Old Logs',         icon: 'delete_sweep', iconColorClass: 'bg-surface-variant text-on-surface-variant',    lastRun: '1 month ago',    schedule: 'Monthly on 1st', enabled: false },
]

export default function ScheduledTask() {
  const navigate = useNavigate()
  const [activeFilter, setActiveFilter] = useState<FilterType>('All')
  const [tasks, setTasks] = useState<Task[]>(MOCK_TASKS)

  const filters: FilterType[] = ['All', 'Enabled', 'Disabled']

  const filteredTasks = tasks.filter((t) => {
    if (activeFilter === 'Enabled') return t.enabled
    if (activeFilter === 'Disabled') return !t.enabled
    return true
  })

  const handleToggle = async (id: string) => {
    // Optimistic update
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, enabled: !t.enabled } : t))
    )
    // TODO: await axios.patch(`/api/tasks/${id}/toggle`)
  }

  const handleRun = async (id: string) => {
    // TODO: await axios.post(`/api/tasks/${id}/run`)
    console.log('Running task', id)
  }

  return (
    <div className="flex-1 flex flex-col md:ml-sidebar-width h-full">
      <Header title="Scheduled Task" />

      <main className="flex-1 overflow-y-auto p-4 md:p-lg bg-surface">
        <div className="max-w-6xl mx-auto space-y-6">

          {/* Page header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h2 className="font-page-title text-page-title text-on-surface">Task List</h2>
            <button
              onClick={() => navigate('/new-task')}
              className="h-[36px] px-4 bg-primary text-on-primary rounded font-medium text-sm flex items-center justify-center gap-2 hover:bg-primary-container transition-colors shadow-sm"
            >
              <span className="material-symbols-outlined text-[18px]">add</span>
              New Task
            </button>
          </div>

          {/* Filter tabs + task list card */}
          <div className="bg-surface-container-lowest rounded-xl border border-outline-variant shadow-[0_4px_24px_rgba(0,0,0,0.02)] overflow-hidden">

            {/* Filter tabs */}
            <div className="border-b border-outline-variant px-6 flex items-center gap-6 bg-surface-container-lowest">
              {filters.map((f) => (
                <button
                  key={f}
                  onClick={() => setActiveFilter(f)}
                  className={`py-4 text-sm font-medium border-b-2 transition-colors ${
                    activeFilter === f
                      ? 'text-primary border-primary'
                      : 'text-on-surface-variant hover:text-on-surface border-transparent'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>

            {/* Task rows */}
            <div className="divide-y divide-outline-variant">
              {filteredTasks.map((task) => (
                <div
                  key={task.id}
                  className={`p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4 hover:bg-surface-container-low/30 transition-colors ${!task.enabled ? 'opacity-75' : ''}`}
                >
                  {/* Left: icon + name + last run */}
                  <div className="flex items-start gap-4 flex-1">
                    <div className={`w-10 h-10 rounded flex items-center justify-center shrink-0 ${task.iconColorClass}`}>
                      <span className="material-symbols-outlined">{task.icon}</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-on-surface text-base">{task.name}</h3>
                      <p className="font-meta text-meta text-on-surface-variant mt-1">Last run: {task.lastRun}</p>
                    </div>
                  </div>

                  {/* Right: schedule + toggle + buttons */}
                  <div className="flex items-center flex-wrap gap-4 lg:justify-end">
                    {/* Schedule badge */}
                    <span className="px-3 py-1 bg-surface-container-high text-on-surface font-meta text-meta rounded-full whitespace-nowrap flex items-center gap-1">
                      <span className="material-symbols-outlined text-[14px]">schedule</span>
                      {task.schedule}
                    </span>

                    {/* Toggle */}
                    <div
                      onClick={() => handleToggle(task.id)}
                      className={`w-10 h-6 rounded-full relative cursor-pointer shadow-inner transition-colors ${
                        task.enabled
                          ? 'bg-primary'
                          : 'bg-surface-variant border border-outline-variant/50'
                      }`}
                    >
                      <div
                        className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${
                          task.enabled ? 'right-1' : 'left-1'
                        }`}
                      />
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => navigate(`/tasks/${task.id}`)}
                        className="h-[36px] px-4 bg-surface-container-lowest border border-outline-variant text-primary rounded font-medium text-sm hover:bg-surface-container-low transition-colors shadow-sm"
                      >
                        View
                      </button>
                      <button
                        onClick={() => task.enabled && handleRun(task.id)}
                        disabled={!task.enabled}
                        className={`h-[36px] px-4 rounded font-medium text-sm shadow-sm transition-colors ${
                          task.enabled
                            ? 'bg-primary text-on-primary hover:bg-primary-container'
                            : 'bg-surface-variant text-on-surface-variant cursor-not-allowed'
                        }`}
                      >
                        Run
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              {filteredTasks.length === 0 && (
                <div className="p-12 flex flex-col items-center gap-3 text-on-surface-variant">
                  <span className="material-symbols-outlined text-[48px] opacity-30">checklist</span>
                  <p className="font-body text-body">No tasks found</p>
                </div>
              )}
            </div>
          </div>

        </div>
      </main>
    </div>
  )
}
