# Step 2: Write the brag plan (plan + storyboard, single step)

Write `<output-dir>/brag-plan.md`. One focused page. This is the creative
north star for the entire video.

This step folds video-planning (story arc, scene timeline, duration
negotiation) and storyboarding (per-scene text/motion/audio detail)
into a single pass — do not split these into separate skill
invocations. One consolidated document, one gate.

The plan should specify what the video must communicate and what project
material must be used. It should not prescribe low-level Hyperframes
implementation details. Hyperframes will decide the concrete composition
structure, animation mechanics, and render workflow from the brief in
Step 3.

## Create the output directory

```bash
mkdir -p <output-dir>
```

## Mode (decide this first — it sets every duration/scene-count rule below)

| Mode | Target length | Purpose | Real UI capture (Step 0) |
|---|---|---|---|
| `short` (default) | 15-25s | Fast, postable launch sting | Optional — falls back to code-read recreation if no live app |
| `promo` | 2-3 min (120-180s) | A proper promotional piece: story, product, proof, CTA | Recommended whenever a live app exists |
| `demo` | ~5 min (280-320s) | Walkthrough of the actual product for prospects/customers | **Required** — Step 0 must run; this mode exists specifically to show the real app working, not a stylized sting |

Parse `--mode short|promo|demo`. If not given, infer:
- User says "launch video", "brag about this", "short clip" -> `short`.
- User says "promo video", "promotional video", "2-3 minute", "marketing video" -> `promo`.
- User says "demo", "walkthrough", "show how it works", "product tour", or gives a duration around 5 minutes -> `demo`.
- If ambiguous, ask one question: "Quick 15-25s sting, a 2-3 min promo, or a ~5 min demo walkthrough?"

The Creative laws "Short. 15-25 seconds." rule in SKILL.md applies only to
`short` mode. `promo` and `demo` have their own pacing rules below — longer
is correct for those modes, not a violation of the skill's spirit.

## Structure of brag-plan.md

```markdown
# Brag Plan: [App Name]

## Mode
[short / promo / demo] — [target duration]

## What is this app?
[One sentence. What it does, what makes it funny or impressive.]

## The angle
[The creative premise. The joke, the hook, the claim (short mode) —
or the core value proposition and proof points (promo/demo mode).
What makes this video specific to this project and not generic.]

## Story arc
[Name the arc being used: hook-build-payoff (short), setup-problem-solution-proof-CTA
(promo), or orientation-walkthrough-recap (demo). One line per beat of the arc,
naming what happens at each stage. This replaces needing a separate video-plan
pass — the arc and the storyboard below are the same document.]

## Hook (first 2-3 seconds)
[The opening moment. This is the most important decision regardless of mode —
promo/demo videos are skipped in the first 3 seconds just as easily as short ones.]

## Key moments / proof points
[short mode: 2-3 sharp highlights. promo/demo mode: the full set of features,
proof points, or flow stages this length allows — still specific, never generic
feature-card filler.]

## Real UI captured (Step 0)
[List capture files used and which scene each maps to, or "none — recreated
from source" with the reason, per step-0-capture-ui.md.]

## User flow worth showing
[The 2-3+ beats of *using* the product (entry -> key action -> result), pulled
from Step 1 question 9. demo mode should show the FULL flow, not just 2-3 beats.]

## Outro / punchline / CTA
[short mode: the final line, the beat before the logo.
promo/demo mode: a clear call to action — sign up, contact, try it, link.]

## Tone
- Preset: [default / polished / yc-parody / chaotic / deadpan / cinematic / app-store]
- Creative direction: [freeform phrase, inferred or user-provided]
- Interpretation: [one sentence on how this affects pacing, writing, visual energy, and restraint]

## Format: [landscape / vertical / square] — [width]x[height]
## Duration: [target seconds, per mode table above]

## Visual identity (from the project)
- Background: [exact color value]
- Accent: [exact color value]
- Text: [exact color value]
- Display font: [name]
- Body font: [name]
- Strongest visual element: [what from the site to reference]

## Share copy (draft)
[One sentence for Twitter/X/LinkedIn/Discord. Punchy. Not corporate.
For promo/demo mode, also draft a one-paragraph description suitable
for a YouTube/Vimeo listing.]

## Audio direction
- Role: [warm bed / sparse professional accents / cinematic support / dense rhythmic layer / intentional silence]
- Music: [candidate track / mood / none only if disabled, missing, or intentionally silent]
- Music treatment: [start time, volume posture, fade-in/out intent, beat/swell notes]
- Music cue guidance: [preset cue file read / unavailable; list 1-3 strong cue timestamps for major moments; list beat-grid windows for sequential events]
- Audio-reactive treatment: [none / subtle / expressive; what visual qualities may respond to music energy]
- SFX posture: [sparse / moderate / dense; motion-matched; professional restraint]
- Audio-coupled moments: [visual ideas that should consider sound, e.g. typed text, beat reveal, count-up, card sequence]
- Restraint rule: [what audio must not do]
- Voiceover: [if --voice, note narration posture here; promo/demo mode narration should guide the viewer through proof points / flow steps, not just add mood]

## Scene Timeline

| # | Timecode | Duration | Arc beat | Real capture used | Description | Sequential/interaction | Audio intent | Transition -> next |
|---|---|---:|---|---|---|---|---|---|
| 1 | 00:00-00:04 | 4s | Hook | [capture file or "recreated"] | [what's on screen, what text] | [yes - describe, or none] | [emotional intent] | [mood] |
| 2 | ... | | | | | | | |

[Continue for all scenes. This single table replaces a separate storyboard-grid
or video-storyboard pass — every column downstream steps need is here.]

**Music mood for this video:** [upbeat / cinematic / chaotic / deadpan / parody / none only if disabled / missing / intentionally silent]
**Audio summary:** [one sentence describing the full audio arc]
```

## Planning the scenes

The default pattern (short mode) is:
```
Hook -> Reveal -> 2-3 highlights -> Punchline/outro
```

For `promo` mode, use:
```
Hook -> Problem/context -> Product reveal -> 3-5 proof points or flow beats -> Social proof (if available) -> CTA
```

For `demo` mode, use:
```
Hook -> What this is (10-15s) -> Full walkthrough of the real flow, beat by beat,
using every Step 0 capture in flow order -> Recap of value -> CTA
```

Scene counts by mode and tone:

| Mode | Scenes | Pacing |
|---|---|---|
| `short` | 4-8 (see tone table below) | As before — see tones.md |
| `promo` | 10-18 | Each scene 8-15s; proof points get room to land, still no dead air |
| `demo` | 15-30 | Each scene 10-20s; walkthrough paced to real flow, not artificially rushed or padded |

Tone still modulates energy within a mode (e.g. a `chaotic` promo still cuts
faster than a `polished` promo), but mode sets the scene-count floor/ceiling.

## Duration guidance (per mode)

- `short`: scene durations must sum to 15-25 seconds. Under 15s is too thin;
  over 25s, cut or tighten. 18-22s is the sweet spot.
- `promo`: scene durations must sum to 120-180 seconds. Pad with proof, not
  with slower versions of the same beat — if you're short, add another
  specific proof point or flow beat, don't just hold existing scenes longer.
- `demo`: scene durations must sum to 280-320 seconds. The walkthrough should
  map to the real flow's natural pacing — don't compress a 5-click flow into
  3 fast cuts just to hit a scene-count target. Fidelity to the real flow
  outranks editing punchiness in this mode.

## Reading time (keep the pace, not at text's expense)

High pace comes from fast motion, fast transitions, and tight cuts — NOT
from pulling text off screen before it can be read. Every text element a
viewer must read needs enough fully-visible, settled time (entered, not yet
exiting) to actually read it:

- Short label or 1-3 word line: about 0.8s settled.
- Headline or full sentence: about 0.3s per word, minimum ~1.2s. The hook
  line gets the most.

This rule is mode-independent — a 5-minute demo full of unreadable flashing
labels is just as broken as a 20-second sting with the same problem.

## Choosing what to show

Every brag video must show something real from the product. Options, in
preferred order — and this order is now a fidelity order, not just a
creative-strength order:

1. **Use a real captured screenshot/recording from Step 0** — the actual
   app, actually captured. This is the only option for `demo` mode's
   centerpiece scenes, and strongly preferred for `promo` mode whenever a
   live app exists.
2. **Recreate a working-app moment in HTML** — only when Step 0 could not
   run (no live app reachable) or for `short` mode when a live capture
   wasn't gathered. Use real source from `app/`, `pages/`, or routed
   components. Clearly weaker fidelity than option 1 — say so in the plan.
3. **Recreate a UI element in HTML** — a hero card, swipe UI, progress
   meter, stat block. Strong when there is no flow to show.
4. **Animate the core concept** — pure graphic but grounded in the idea.
5. **Text-forward sequence** — if the product is copy-driven, let the copy
   be the visual.

Never fill scenes with abstract patterns, color washes, or generic motion
graphics that could belong to any video.

## Bias the storyboard toward the user flow

If Step 1 question 9 identified a real user flow, the **centerpiece scenes
must show that flow** — using Step 0 captures when they exist, not just
landing-page recreations. In `demo` mode, the entire flow is the video;
in `short`/`promo` mode, it's the 2-3 (or more, for promo) strongest beats.

Good (working-app scenes, capture-backed):
- "Scene 4 — dashboard.png (Step 0 capture) — cursor highlights the upload
  button, cut to 05-processing.png showing the real progress state."

Avoid (marketing-only scenes when a flow and captures exist):
- "16:9 -> 9:16 transform diagram" when a real capture of that exact
  transform exists and isn't used.

## Look for interaction and sequential reveal moments

Before finalizing the Scene Timeline, ask: **does this product have things
that can appear one by one, or actions that can be simulated?**

Design these explicitly into the Scene Timeline's "Sequential/interaction"
column — this is a storyboard decision, not an audio afterthought. If a
real Step 0 recording already shows the interaction, prefer referencing
that recording over simulating it in HTML.

## Audio planning

Choose the music direction in the plan. Leave exact SFX file selection and
exact timestamps to Hyperframes during composition, because SFX should
match the actual visual implementation.

Default posture: include audio. Pick a music bed and a few tasteful SFX
unless the user passed `--no-music` / `--no-sfx`, the assets are missing,
or silence is explicitly part of the concept. For `demo` mode specifically,
keep music low/sparse under any narration — demos are information-first.

For each scene in the timeline, the "Audio intent" column captures what the
sound should do emotionally; audio-coupled ideas (typed text, beat-aligned
reveal, counter ticks) can be noted there or in a short prose aside.

## Music cue guidance

Beat/cue sync is available for any track (see `audio.md`). When music is
selected, add a compact note: the track, 1-3 strong-cue timestamps for
major moments, and beat-grid windows for sequential reveals. For `promo`/
`demo` mode with narration, cues should duck under voice, not compete.

## Handoff posture

- Good: "Scene 6 uses `capture/screenshots/04-result.png`, cropped to the
  result card, Ken Burns zoom in over 3s."
- Good: "Use the source site's amber/dark palette and serif headline feel."
- Avoid: "Use a GSAP timeline with this selector and this easing."
- Avoid: "Load this specific runtime URL" (Hyperframes composes from the
  captured assets Step 0 already gathered, not a live fetch).

## Transition vocabulary

Match transitions to tone (same table regardless of mode; promo/demo just
use these transitions more times):

| Tone | Preferred transitions |
|---|---|
| `default` | Crossfade, clean wipe |
| `polished` | Soft crossfade, slide |
| `yc-parody` | Hard cut, minimal |
| `chaotic` | Hard cut, flash, zoom |
| `deadpan` | Slow crossfade, long hold |
| `cinematic` | Dramatic wipe, crossfade |
| `app-store` | Slide, smooth wipe |

## Gate

`<output-dir>/brag-plan.md` exists with: a declared mode, a full Scene
Timeline table, scene durations summing within that mode's target range,
and — for `promo`/`demo` mode where a live app existed — explicit capture
file references rather than generic UI descriptions.
