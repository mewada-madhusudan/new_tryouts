import { NavLink } from 'react-router-dom'

interface NavItem {
  label: string
  icon: string
  to: string
}

const navItems: NavItem[] = [
  { label: 'Mailbox',        icon: 'mail',       to: '/mailbox' },
  { label: 'New Task',       icon: 'add_task',   to: '/new-task' },
  { label: 'All Tasks',      icon: 'list_alt',   to: '/tasks' },
  { label: 'Scheduled Task', icon: 'schedule',   to: '/scheduled' },
  { label: 'Import/Export',  icon: 'swap_horiz', to: '/import-export' },
  { label: 'Logs',           icon: 'terminal',   to: '/logs' },
]

export default function Sidebar() {
  return (
    <nav className="fixed left-0 top-0 h-full w-sidebar-width bg-[#1E1F2E] border-r border-gray-800 flex flex-col py-6 z-20 hidden md:flex">
      {/* Logo */}
      <div className="px-6 mb-8 flex items-center gap-3">
        <div className="w-8 h-8 rounded bg-[#4F6BFF] flex items-center justify-center text-white font-bold text-sm">
          PA
        </div>
        <div>
          <h1 className="text-[13px] font-semibold text-white">Your Personal Assistant</h1>
          <p className="text-[11px] text-[#A0A3B1]">Outlook Automation</p>
        </div>
      </div>

      {/* Nav items */}
      <div className="flex-1 overflow-y-auto font-['Inter'] text-[13px] font-semibold">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              isActive
                ? 'text-white border-l-4 border-[#4F6BFF] bg-[#4F6BFF]/10 flex items-center px-6 py-3 transition-all duration-200 gap-3'
                : 'text-[#A0A3B1] flex items-center px-6 py-3 transition-all hover:bg-white/5 hover:text-white group gap-3'
            }
          >
            {({ isActive }) => (
              <>
                <span
                  className="material-symbols-outlined text-[20px]"
                  style={{
                    fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0",
                    color: isActive ? '#4F6BFF' : undefined,
                    opacity: isActive ? 1 : undefined,
                  }}
                >
                  {item.icon}
                </span>
                {item.label}
              </>
            )}
          </NavLink>
        ))}
      </div>

      {/* Settings at bottom */}
      <div className="mt-auto px-6 font-['Inter'] text-[13px] font-semibold">
        <NavLink
          to="/settings"
          className="text-[#A0A3B1] flex items-center py-3 transition-all hover:bg-white/5 hover:text-white group gap-3"
        >
          <span className="material-symbols-outlined text-[20px] opacity-70 group-hover:opacity-100 transition-opacity">
            settings
          </span>
          Settings
        </NavLink>
      </div>
    </nav>
  )
}
