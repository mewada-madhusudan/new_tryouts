interface HeaderProps {
  title: string
}

export default function Header({ title }: HeaderProps) {
  return (
    <header className="bg-white border-b border-[#E5E7EB] h-[56px] flex justify-between items-center px-6 w-full z-10 shrink-0">
      {/* Mobile title */}
      <div className="text-xl font-semibold text-gray-900 md:hidden">
        Your Personal Assistant
      </div>
      {/* Desktop page title */}
      <div className="hidden md:block text-[#4F6BFF] font-['Inter'] text-[20px] font-semibold">
        {title}
      </div>
      {/* Right: bell + avatar */}
      <div className="flex items-center gap-4">
        <button className="text-gray-500 hover:text-[#4F6BFF] transition-colors hover:scale-105 active:scale-95">
          <span className="material-symbols-outlined">notifications</span>
        </button>
        <div className="flex items-center gap-2 cursor-pointer">
          <span className="text-sm font-medium text-gray-700">Username</span>
          <div className="w-8 h-8 rounded-full bg-surface-container-high overflow-hidden border border-[#E5E7EB] flex items-center justify-center">
            <span className="material-symbols-outlined text-gray-500 text-[18px]">person</span>
          </div>
        </div>
      </div>
    </header>
  )
}
