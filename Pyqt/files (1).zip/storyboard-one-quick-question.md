# "One Quick Question": storyboard (Video 1 of 3)

Length: about 2:50. Format: 16:9, 1920x1080, 30 fps. Style: hand-drawn doodle on graph paper, wobble "boil" on every line.
Sound: keyboard clicks, a tinny leaking music loop, comic pops. Dialogue is handwritten speech bubbles with short mumble blips. Voiceover is optional.

## Creative brief
- **Goal:** make the team laugh at their own day and want to share it.
- **Audience:** these nine people, plus anyone who has worked in a busy dev room.
- **Single message:** in this room, one simple answer takes nine opinions, one muted Zoom and one pair of loud earbuds to arrive.
- **Tone:** warm, affectionate teasing. Nobody is the villain; every joke is a habit, not a flaw.

## Assumptions to confirm
1. Window wall is the back wall of the stage. Window-side row (back to the window, facing the room): Vinoth, Charles, Vinay. Opposite row (facing the windows, seen from behind): Ankurit, Chandra, Madhusudan, with Madhusudan on the corner next to Saba's table. See `office-layout.svg`.
2. "Give him a juggle" is read as a nudge. In the story, Charles tosses a paper ball.
3. The problem is a harmless made-up one: "The dashboard shows yesterday's numbers." Change it to a real in-joke any time.
4. Vishwas appears on a laptop screen (Zoom window), Saba at the right-hand desk, Santhosh at the head of the table.

## Stage design
- One fixed "dollhouse" stage: window with a gentle scenery loop (trees, passing cloud, a crane in the distance) across the back wall, long table across the middle, vertical desk on the right, head chair on the left.
- Window-side row faces the camera. The opposite row is seen from behind (back-of-head view) and swivels around to face camera when they speak, with a spin-chair whoosh.
- Plan view (`office-layout.svg`) is used only in the opening shot.
- Camera: mostly locked. Slow push-ins on punchlines, one quick shake in the chaos scene.

## Character gag sheet (each one has one running joke)
| Character | Running gag | Animation hook |
| --- | --- | --- |
| Saba | Starts everything with "Quick question..." | Stands, taps desk, points; facepalm in chaos |
| Vishwas | Appears on Zoom, says "Guys--" then keeps talking, usually on mute | Laptop window pop, mic icon with a red slash, waving |
| Vinoth | Thinks so hard a flowchart grows out of his head | Thought bubble that keeps adding boxes and arrows |
| Charles | Doodles everything, including the doodle you are watching | Draws tiny doodles of the others in a notebook; draws a cat instead of a solution |
| Santhosh | Answers before the question ends; in every conversation | Chair swivels toward each speaker, speech bubble already open |
| Vinay | Walks silently, nobody notices | Glides across the back with a trail of tiny footprints |
| Ankurit | "It's not the frontend." | Defensive hands-up, a small CSS badge appears |
| Chandra | Says exactly one sentence, no more | Speaks once, in a small bubble, then folds hands |
| Madhusudan | Loud earbuds, music notes leak out, head always bobbing | Notes drift across the room and make people wince |

## Scenes

### 1. Title (0:00 to 0:10)
- Plan-view seating chart draws itself on paper. Names scribble in one by one.
- Clock bubble: "11:07 AM". Title writes on: "One Quick Question".
- Audio: pencil scratch, soft clock tick. Transition: paper zooms down into the stage.

### 2. Meet the room (0:10 to 0:30)
- Stage reveals. Keyboards clack. Sticky-note labels pop above heads as the camera pans left to right:
  Saba "Boss", Vishwas "Boss+ (on Zoom)", Vinoth "The Thinker", Charles "Doodle Maker", Santhosh "All-Rounder", Vinay "Silent Walker", Ankurit "Frontend", Chandra "Not more, not less", Madhusudan "DJ".
- Beat on Madhusudan: music notes puff out, and every neighbor winces in sequence.
- Audio: keyboards, leaking music loop. Transition: cut.

### 3. A normal calm (0:30 to 0:50)
- Vinay glides across the back, nobody reacts. He does it twice.
- Charles's notebook: close-up of him doodling a tiny Santhosh who is talking. Tiny Santhosh looks back at him.
- Santhosh swivels: "Are we discussing something?" Everyone: "No." Santhosh: "Okay. Carry on."
- Madhusudan bobs to the beat. The window scenery loops. Transition: Saba stands up.

### 4. "Quick question..." (0:50 to 1:05)
- Saba stands: "Quick question..."
- Saba asks Madhusudan first (closest to his desk). No reaction. Louder, bigger gestures. Music notes bounce off Saba's head.
- Saba gives up, turns to the room. Title card scribbles on: "The Problem".
- Saba: "The dashboard is showing yesterday's numbers. Why?"

### 5. Everyone joins (1:05 to 1:30)
- Chandra, quietly, in a small bubble: "Maybe it's the cache." Nobody hears it.
- Ankurit swivels, hands up: "It's not the frontend!" A small badge: "Not CSS."
- Vinoth goes still. A thought bubble starts a flowchart with one box.
- Santhosh: "This happened in March. And in July. Also my phone is slow."
- Charles starts drawing a "diagram".

### 6. Escalation (1:30 to 1:55)
- Bubbles overlap and stack across the screen. Voices layer into mumble blips.
- Vinoth's flowchart grows out of the frame, across the wall, onto the ceiling.
- Charles holds up his diagram to camera: it is a very detailed cat. Everyone stares. He turns it around: "It's also a database."
- Vinay glides through the chaos once more, silently, holding a sticky note we do not see.

### 7. Vishwas on Zoom (1:55 to 2:15)
- Laptop window pops on Vishwas's desk: "Guys--". Mic icon has a red slash. Nobody reacts.
- He keeps talking, bubbles blank. Ankurit: "You're on mute." Vishwas leans in, still nothing.
- He unmutes: "Guys, can you hear me? Guys. Guys, so here's what I think..." and keeps going in a long run-on bubble nobody reads.
- Saba mouths: "Vishwas, one second." Vishwas: "Guys--" (muted again).

### 8. Chaos peak (2:15 to 2:30)
- Everyone talking at once. Speech bubbles start bouncing on the beat of Madhusudan's music, until the whole room is accidentally a rhythmic debate: heads bob together, hands point on the beat.
- Saba facepalms. Camera shakes once.
- Charles balls up a page and tosses it. It hits Madhusudan's head.
- Earbud pops out. The music stops. Total silence. All faces turn to him.
- Madhusudan swivels: "...what?"
- Everyone, together, pointing: "Volume."

### 9. The answer (2:30 to 2:50)
- In the silence, Vinay glides to Saba's desk and sticks a note on the screen. He glides away.
- Saba reads it aloud: "Cache."
- Beat. Saba slowly turns to Chandra. Chandra: "I said that."
- Credit-grab: Santhosh, Ankurit and Vinoth each say "I knew it" at once. Charles holds up the cat: "Cat knew it."
- Vishwas, on mute: "Guys, great job!" Nobody hears.

### 10. Tag (2:50 to 3:00)
- Madhusudan puts his earbud back in. Music resumes. The whole room sighs in sync.
- Saba stands: "Quick question..." Everyone freezes with the same face. Iris-out on the group.
- End card: "Same time tomorrow, 11:07." Pencil scratch, soft clock tick.

## Asset checklist
- Nine characters (done). Needed additionally: back-of-head views for Ankurit, Chandra and Madhusudan; seated poses (torso above desk) for everyone; a swivel-chair spin for the front row.
- Props: long table, vertical desk, nine monitors or laptops, window with scenery loop, notebook, paper ball, sticky notes, Zoom window with mic icon, music notes, speech and thought bubbles, flowchart pieces, clock.
- Audio: keyboard clicks, a short loopable music bed (royalty-free), pencil scratch, chair swivel, paper toss, record-scratch for the music stopping, soft clock tick, mumble blips per character.
- Handwriting font bundled locally.

## Build notes for HyperFrames
- One composition per scene, one master timeline. Use the `wobbleA/B/C` filters on a 3-frame cycle for the boiling-line look.
- Characters are existing SVGs; arms, head, eyes (blink) and mouth (talk) are swapped by id.
- Keep randomness seeded so every render is identical.
- Subtitle-style bubbles are easier to edit than baked voiceover; add voice later if wanted.

## Handoff brief (paste into /brag --full or /hyperframes)
Goal: a 2:50 doodle comedy about nine coworkers solving a problem in one room. Single message: one simple answer takes nine opinions, a muted Zoom and loud earbuds to arrive. Tone: warm, teasing. Format 16:9, 30 fps, graph-paper doodle with line boil. Use the scenes above in order with the timings given. Characters, layout, assets and audio are listed in this file.
